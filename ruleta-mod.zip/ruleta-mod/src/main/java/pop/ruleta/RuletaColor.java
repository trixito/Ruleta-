package pop.ruleta;

public enum RuletaColor {
    AZUL("azul", 0x3B82F6),
    ROJO("rojo", 0xEF4444),
    AMARILLO("amarillo", 0xFACC15),
    CYAN("cyan", 0x22D3EE),
    ROSA("rosa", 0xF472B6),
    MORADO("morado", 0xA855F7),
    VERDE("verde", 0x22C55E),
    NARANJA("naranja", 0xF97316);

    public final String id;
    public final int rgb;

    RuletaColor(String id, int rgb) {
        this.id = id;
        this.rgb = rgb;
    }

    public static RuletaColor of(int ordinal) {
        RuletaColor[] v = values();
        return v[Math.floorMod(ordinal, v.length)];
    }
}
