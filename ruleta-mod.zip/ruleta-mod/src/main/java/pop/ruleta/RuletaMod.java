package pop.ruleta;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class RuletaMod implements ModInitializer {

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(RuletaPayload.ID, RuletaPayload.CODEC);

        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> {
            LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("ruleta")
                    .requires(src -> src.hasPermissionLevel(2));

            for (RuletaColor c : RuletaColor.values()) {
                root.then(CommandManager.literal(c.id)
                        .executes(ctx -> ejecutar(ctx, c, ""))
                        .then(CommandManager.argument("mensaje", StringArgumentType.greedyString())
                                .executes(ctx -> ejecutar(ctx, c, StringArgumentType.getString(ctx, "mensaje")))));
            }
            dispatcher.register(root);
        });
    }

    private static int ejecutar(CommandContext<ServerCommandSource> ctx, RuletaColor color, String mensaje) {
        RuletaPayload payload = new RuletaPayload(color.ordinal(), mensaje);
        for (ServerPlayerEntity p : ctx.getSource().getServer().getPlayerManager().getPlayerList()) {
            ServerPlayNetworking.send(p, payload);
        }
        ctx.getSource().sendFeedback(() -> Text.literal("Ruleta " + color.id + " lanzada."), true);
        return 1;
    }
}
