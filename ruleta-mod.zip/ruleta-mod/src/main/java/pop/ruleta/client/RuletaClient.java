package pop.ruleta.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import pop.ruleta.RuletaColor;
import pop.ruleta.RuletaPayload;

import java.util.Random;

public class RuletaClient implements ClientModInitializer {

    private static final int SPIN_TICKS = 100;   // gira
    private static final int HOLD_END = 190;     // parpadeo del color elegido
    private static final int TOTAL_TICKS = 220;  // desvanecer
    private static final int BLINK_TICKS = 5;    // cada cuántos ticks alterna

    // Pixel art: rueda 48px, marco 64px, puntero 16px; todo dibujado al doble (2x)
    private static final int WHEEL = 96;
    private static final int FRAME = 128;
    private static final int POINTER = 32;

    private static final Identifier RUEDA = Identifier.of("ruleta", "textures/gui/ruleta.png");
    private static final Identifier SEGMENTO = Identifier.of("ruleta", "textures/gui/segmento.png");
    private static final Identifier MARCO = Identifier.of("ruleta", "textures/gui/marco.png");
    private static final Identifier PUNTERO = Identifier.of("ruleta", "textures/gui/puntero.png");

    private static final Random RANDOM = new Random();

    private static int ticks = -1;
    private static RuletaColor color = RuletaColor.AZUL;
    private static String mensaje = "";
    private static float anguloFinal = 0;
    private static int lastTickSound = -1;
    private static int lastBlink = -1;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(RuletaPayload.ID, (payload, ctx) ->
                ctx.client().execute(() -> iniciar(RuletaColor.of(payload.color()), payload.mensaje())));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (ticks < 0) return;
            ticks++;
            if (mc.player != null) {
                if (ticks < SPIN_TICKS) {
                    float x = ticks / (float) SPIN_TICKS;
                    int intervalo = 2 + (int) (x * x * 10);
                    if (ticks - lastTickSound >= intervalo) {
                        lastTickSound = ticks;
                        mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_HAT.value(), 0.5f, 1.0f + (1f - x) * 0.5f);
                    }
                } else if (ticks == SPIN_TICKS) {
                    mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
                    mostrarEnChat(mc);
                } else if (ticks < HOLD_END) {
                    int fase = (ticks - SPIN_TICKS) / BLINK_TICKS;
                    if (fase != lastBlink) {
                        lastBlink = fase;
                        mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 0.35f, fase % 2 == 0 ? 1.4f : 1.0f);
                    }
                }
            }
            if (ticks >= TOTAL_TICKS) ticks = -1;
        });

        HudRenderCallback.EVENT.register((gfx, tickCounter) -> render(gfx, tickCounter.getTickDelta(false)));
    }

    private static void iniciar(RuletaColor c, String msg) {
        color = c;
        mensaje = msg;
        // el segmento i queda arriba (bajo el puntero) con ángulo = 360 - i*45
        float base = (360f - c.ordinal() * 45f) % 360f;
        float jitter = RANDOM.nextInt(25) - 12; // dentro del segmento
        anguloFinal = 360f * 5 + base + jitter;
        lastTickSound = -1;
        lastBlink = -1;
        ticks = 0;
    }

    private static void mostrarEnChat(MinecraftClient mc) {
        String texto = mensaje.isEmpty() ? "Salió " + color.id : mensaje;
        Text linea = Text.literal("[Ruleta] ").setStyle(Style.EMPTY.withColor(0x22D3EE).withBold(true))
                .append(Text.literal(texto).setStyle(Style.EMPTY.withColor(color.rgb)));
        mc.inGameHud.getChatHud().addMessage(linea);
    }

    private static void render(DrawContext gfx, float delta) {
        if (ticks < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        float t = ticks + delta;
        float alpha = t < 10 ? t / 10f : (t > HOLD_END ? Math.max(0f, (TOTAL_TICKS - t) / (TOTAL_TICKS - HOLD_END)) : 1f);

        float x = Math.min(1f, t / SPIN_TICKS);
        float ease = 1f - (float) Math.pow(1f - x, 3);
        float angulo = anguloFinal * ease;
        boolean parado = t >= SPIN_TICKS;

        int w = gfx.getScaledWindowWidth();
        int h = gfx.getScaledWindowHeight();
        float fit = Math.min(1f, h / 300f);
        int cx = w / 2;
        int cy = Math.max((int) (h * 0.3f), (int) (80 * fit));
        float escala = (t < 10 ? 0.6f + 0.4f * (t / 10f) : 1f) * fit;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        MatrixStack m = gfx.getMatrices();
        m.push();
        m.translate(cx, cy, 0);
        m.scale(escala, escala, 1f);

        // marco Tek fijo con pulso suave
        float pulso = 0.82f + 0.18f * (float) Math.sin(t * 0.3f);
        RenderSystem.setShaderColor(pulso, pulso, pulso, alpha);
        gfx.drawTexture(MARCO, -FRAME / 2, -FRAME / 2, 0, 0, FRAME, FRAME, FRAME, FRAME);

        // rueda multicolor (se atenúa al elegir para resaltar el color ganador)
        float brillo = parado ? 0.45f : 1f;
        RenderSystem.setShaderColor(brillo, brillo, brillo, alpha);
        m.push();
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angulo));
        gfx.drawTexture(RUEDA, -WHEEL / 2, -WHEEL / 2, 0, 0, WHEEL, WHEEL, WHEEL, WHEEL);
        m.pop();

        // segmento elegido alternando entre su color y blanco
        if (parado) {
            boolean fase = ((int) ((t - SPIN_TICKS) / BLINK_TICKS)) % 2 == 0;
            float r = fase ? ((color.rgb >> 16) & 0xFF) / 255f : 1f;
            float g = fase ? ((color.rgb >> 8) & 0xFF) / 255f : 1f;
            float b = fase ? (color.rgb & 0xFF) / 255f : 1f;
            RenderSystem.setShaderColor(r, g, b, alpha);
            m.push();
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angulo + color.ordinal() * 45f));
            gfx.drawTexture(SEGMENTO, -WHEEL / 2, -WHEEL / 2, 0, 0, WHEEL, WHEEL, WHEEL, WHEEL);
            m.pop();
        }

        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
        gfx.drawTexture(PUNTERO, -POINTER / 2, -WHEEL / 2 - POINTER + 8, 0, 0, POINTER, POINTER, POINTER, POINTER);
        m.pop();

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
