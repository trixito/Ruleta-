package pop.ruleta;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record RuletaPayload(int color, String mensaje) implements CustomPayload {
    public static final Id<RuletaPayload> ID = new Id<>(Identifier.of("ruleta", "animacion"));
    public static final PacketCodec<RegistryByteBuf, RuletaPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, RuletaPayload::color,
            PacketCodecs.STRING, RuletaPayload::mensaje,
            RuletaPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
